declare module "@salesforce/apex/AccountController.getAccountList" {
  export default function getAccountList(): Promise<any>;
}
