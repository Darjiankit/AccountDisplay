import { LightningElement,track } from 'lwc';
import getAccountList from '@salesforce/apex/AccountController.getAccountList';

export default class DisplayAccounts extends LightningElement {

    @track  columns = [
    
        { label: 'Account Name', fieldName: 'NameUrl', type: 'url', 
     typeAttributes:{
         label:{ fieldName: 'Name' }
     }},
      {label: 'Account Owner', fieldName: 'OwnerId'},
        { label: 'Website', fieldName: 'Website'},
        { label: 'Phone', fieldName: 'Phone' },
        { label: 'Industry', fieldName: 'Industry' },
        { label: 'Annual Revenue', fieldName: 'AnnualRevenue' }

    ];
   @track accountList = [];
    connectedCallback(){
        this.handleClick();
    }
        handleClick(){
            getAccountList()
            .then(result => {
                this.accountList = result;
                console.log('result',result);
                this.dataList = result;
                this.accountList.forEach(item => {
                item['NameUrl'] = '/lightning/r/Account/' +item['Id'] +'/view';
                
    
            });
            })
            .catch(error => {
                this.error = error;
            });
    }
    
    doSorting(event) {
        this.sortBy = event.detail.fieldName;
        this.sortDirection = event.detail.sortDirection;
        this.sortData(this.sortBy, this.sortDirection);
      }
    
      sortData(fieldname, direction) {
        let parseData = JSON.parse(JSON.stringify(this.accountList));
        // Return the value stored in the field
        let keyValue = (a) => {
          return a[fieldname];
        };
        // cheking reverse direction
        let isReverse = direction === "asc" ? 1 : -1;
        // sorting data
        parseData.sort((x, y) => {
          x = keyValue(x) ? keyValue(x) : ""; // handling null values
          y = keyValue(y) ? keyValue(y) : "";
          // sorting values based on direction
          return isReverse * ((x > y) - (y > x));
        });
        this.accountList = parseData;
      }
        }