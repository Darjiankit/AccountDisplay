import { LightningElement, track} from 'lwc';
import getAllLeads from '@salesforce/apex/LeadsController.getAllLeads'
import getOpenNotContactedLeads from '@salesforce/apex/LeadsController.getOpenNotContactedLeads'
import getWorkingContactedLeads from '@salesforce/apex/LeadsController.getWorkingContactedLeads'
import getClosedConvertedLeads from '@salesforce/apex/LeadsController.getClosedConvertedLeads'
import getClosedNotConvertedLeads from '@salesforce/apex/LeadsController.getClosedNotConvertedLeads'


const COLUMNS = [{label: 'Name',fieldName: 'Name' },
{label: 'Company',fieldName:'Company'},
{label: 'Email',fieldName:'Email'},
{label: 'Phone',fieldName:'Phone'},
{label: 'Status',fieldName:'Status'}];

export default class LeadsFilter extends LightningElement {
    columns=COLUMNS;
   
    @track errors;
    @track Leads;
    @track showleads;
    @track workingdata;
    @track shownotContactedLeads;
    @track workingleads
    @track WorkingContactedLeads;
    @track convertedleads;
    @track convert;

    onShowClick(){
        getAllLeads()
        .then(result =>{
            this.Leads =result;
            this.showleads = true;
            console.log(result);
        })
        .catch(error=>{
            console.log('Errorured:- '+error.body.message);  
        });
    }

    onDataClick(){
        getOpenNotContactedLeads()
        .then(results =>{
            this.workingdata =results;
           this.shownotContactedLeads = true;
           console.log(results);
        })
        .catch(error => {
            this.error = error; 
        });

    }
    onworkClick(){
        getWorkingContactedLeads()
        .then(result =>{
            this.workingleads =result;
            this.WorkingContactedLeads = true;
        })
        .catch(error=>{
            console.log('Errorured:- '+error.body.message);  
        });
    }
    onConvertClick(){
        getClosedConvertedLeads()
        .then(result =>{
            this.convertedleads =result;
            this.convert = true;
            console.log(result);
        })
        .catch(error=>{
            console.log('Errorured:- '+error.body.message);  
        });
    }
    oncloseClick(){
        getClosedNotConvertedLeads()
        .then(result =>{
            this.Leads =result;
            this.showleads = true;
        })
        .catch(error=>{
            console.log('Errorured:- '+error.body.message);  
        });

    }



}
    



  /*  @wire(getAllLeads)
    
    allstatus({ error, data }){
        if (data) {
            this.allstatus = data;
      } else if (error) {
            this.errorMsg = error;
      }
    }
    handleAllStages() {
        this.opps = this.allstatus;
        console.log(this.handleAllStages);

    }*/